

const proficiencyList = [
			"acrobatics","animalhandling","arcana","athletics","deception","history",
			"insight","intimidation","investigation","medicine","nature","perception",
			"performance","persuasion","religion","sleightofhand","stealth","survival"
		] 

// Attribute setters backend
function setup(character) {
	//document.getElementById("name").textLength.baseVal.newValueSpecifiedUnits(SVGLength.SVGLENGTHTYPE_PX, 200);
	setName(character.fname, character.lnames);
	setStats(character.stats);
	setProfMod(character.level);
	setAttr('inspiration', '0');
	setDesc(
		character.charClass, 
		character.level,
		character.race,
		character.background,
		character.alignment,
		character.playername,
		character.experience
	);
	setAttr('ac', String(character.statModifiers(1) + 10));
	setAttr('initiative', character.statModifiers(1) >= 0 ? '+'+String(character.statModifiers(1)) : String(character.statModifiers(1)));
	setAttr('speed', String(raceStats[character.race][0]) + 'ft');
	setAttr('passiveperc', String(10 + character.statModifiers(4)));
	
	setSavingThrows(character);
	setSkills(character);
	
	setAttr('maxhp', String(character.conditionStats[0]));
	setAttr('currenthp', String(character.conditionStats[1]));
	setAttr('temphp', String(character.conditionStats[2]));
	setAttr('currenthp', String(character.conditionStats[0]));
}

function setName(firstname, lastnames) {
	document.getElementById("name").innerHTML = firstname + " " + lastnames;
	resizeTextSingleLine(document.getElementById("name"), firstname + " " + lastnames, 25, 24);
}

function resizeTextSingleLine(elem, str, basesize, basecharlen) {
	let size = Math.floor(basesize * basecharlen / str.length);
	if (str.length > basecharlen) {
		elem.style.fontSize = String(size) + "px";
	}
}

function setStats([str, dex, con, intel, wis, cha]) {
	statModToString(0, str);
	statModToString(1, dex);
	statModToString(2, con);
	statModToString(3, intel);
	statModToString(4, wis);
	statModToString(5, cha);
}

function statModToString(statid, stat) {
	document.getElementById('stat'+String(statid)).innerHTML = stat;
	document.getElementById('statmod'+String(statid)).innerHTML = (stat-10 >= 0) ? "+" + String(Math.floor((stat - 10) / 2)) : String(Math.floor((stat - 10) / 2));	
}	

function setProfMod(level) {
	const modifier = 1 + Math.ceil(level / 4);
	document.getElementById("profmod").innerHTML = "+" + String(modifier);
}

function setAttr(name, val) {
	document.getElementById(name).innerHTML = val;
}

function setDesc(cls, lvl, race, bkg, algn, pname, exp) {
	document.getElementById("class").innerHTML = cls + ", " + lvl;
	document.getElementById("race").innerHTML = race;
	document.getElementById("background").innerHTML = bkg;
	document.getElementById("alignment").innerHTML = algn;
	document.getElementById("playername").innerHTML = pname;
	document.getElementById("exp").innerHTML = exp;
}

function setSavingThrows(character) {
	let i = 0;
	character.savingThrows.forEach(e => {
		const modifier = character.statModifiers(i) + (e ? 1 + Math.ceil(character.level / 4) : 0);
		setAttr('statsave'+String(i), modifier >= 0 ? '+' + String(modifier) : String(modifier));
		e ? toggleProficiency('statsaveprof'+String(i)) : undefined;
		i++;
	});
}

function setSkills(character) {
	let i = 0;
	character.proficiencies.forEach(e => {
		const modifier = character.statModifiers(skillStatBase[i]) + (e ? 1 + Math.ceil(character.level / 4) : 0);
		setAttr('skill'+String(i), modifier >= 0 ? '+' + String(modifier) : String(modifier));
		e ? toggleProficiency('skillprof'+String(i)) : undefined;
		i++;
	})
}

function mousepos() {
	
	const coord = () => document.getElementById("sheetsvg").getBoundingClientRect();
	
	document.addEventListener('mousemove', e => {
		let {left, top} = coord();
		const p = String(e.clientX - left) + ', ' + String(e.clientY - top);
		document.getElementById("pos").innerHTML = p;	
	});
}

function toggleProficiency(prof) {
	const elem = document.getElementById(prof);
	elem.getAttribute("opacity") == "0" ? elem.setAttribute("opacity", "0.4") : elem.setAttribute("opacity", "0");	
}


// 
if (typeof window != 'undefined') {
	window.onload = () => {
		charJSON = JSON.stringify(exampleChar);
		
		const charObj = new Character(charJSON);

		setup(charObj);
		
		mousepos();
	}	
}