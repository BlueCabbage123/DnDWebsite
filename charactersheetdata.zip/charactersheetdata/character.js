
class Character {
	constructor(characterJSON) {	
		const 
			newCharacter = JSON.parse(characterJSON);
		
		this.fname = newCharacter.fname;
		this.lnames = newCharacter.lnames;
		
		this.level = newCharacter.level;
		this.charClass = newCharacter.charClass;
		this.race = newCharacter.race;
		this.background = newCharacter.background;
		this.alignment = newCharacter.alignment;
		this.playername = newCharacter.playername;
		this.experience = newCharacter.experience;
		
		this.stats = newCharacter.stats;
		this.statModifiers = n => Math.floor((this.stats[n] - 10) / 2);
		this.savingThrows = newCharacter.savingThrows;
		this.proficiencies = newCharacter.proficiencies;
		
		this.conditionStats = newCharacter.conditionStats;
	}
	
}

// Information consts
const 
	raceStats = {
		dragonborn: [30], // [speed]
		dwarf: [30],
		elf: [30],
		gnome: [25],
		halfelf: [30],
		halforc: [30],
		halfling: [25],
		human: [30],
		tiefling: [30]
	},
	skillIndex = {
		acrobatics: 0,
		animalhandling: 1, 
		arcana: 2, 
		athletics: 3, 
		deception: 4, 
		history: 5, 
		insight: 6, 
		intimidation: 7, 
		investigation: 8, 
		medicine: 9, 
		nature: 10, 
		perception: 11, 
		performance: 12, 
		persuasion: 13, 
		religion: 14, 
		sleightofhand: 15, 
		stealth: 16, 
		survival: 17
		
	},
	skillStatBase = [1,4,3,0,5,3,4,5,3,4,3,4,5,5,3,1,1,4], // Maps skill id to relevant stat id
	exampleChar = {
		fname: 'Kava',
		lnames:'Proazheck',
		level: 1,
		charClass: 'priest',
		race: 'human',
		background: 'sailor',
		alignment: 'evil',
		playername: 'felix',
		experience: 0,
		
		stats: [9,12,14,11,12,19], // [str, dex, con, int, wis, cha]
		savingThrows: [0,1,1,0,0,0], // [str, dex, con, int, wis, cha]
		proficiencies: [0,0,0,0,1,0,1,0,0,0,0,1,0,1,0,0,0,0], // [acrobatics, animalhandling, arcana, athletics, 
															  //  deception, history, insight, intimidation, investigation, 
															  //  medicine, nature, perception, performance, persuasion, 
															  //  religion, sleightofhand, stealth, survival]
				
		conditionStats: [12, 12, 0, 2, 1, 0, 0] // [maxhp, currenthp, temphp, totalhitdice, currenthitdice, deathsavesuccess, deathsavefailure]
	};



























